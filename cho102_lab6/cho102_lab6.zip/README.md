# Lab 6

## Student information

* Full name: Cindy Ho
* E-mail: cho102@ucr.edu
* UCR NetID: cho102 
* Student ID: 862151318

## Answers

* (Q1) What are these two arguments? </br> One of the commands from the different cases and the input file.

* (Q2) If you do this bonus part, copy and paste your code in the README file as an answer to this question.

* (Q3) What is the type of the attributes `time` and `bytes` this time? Why? </br> The attributes of `time` and `bytes` are parsed as strings because spark doesn't try to infer that they are integers.

* (Q4) If you do this bonus part, copy and paste your code in the README file as an aswer to this question.
